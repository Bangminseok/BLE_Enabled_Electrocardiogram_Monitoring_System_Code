const mysql = require("mysql2/promise");

// mysql 접속 정보
const pool = mysql.createPool({
    host: "localhost",
    user: "root",
    password: "root",
    database: "ecg",
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0,
});

module.exports = pool;
