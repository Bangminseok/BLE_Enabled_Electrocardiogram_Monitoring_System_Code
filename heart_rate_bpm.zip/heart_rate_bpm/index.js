const express = require("express");
const cors = require("cors");
// 라우터 연결
const ecgRoutes = require("./app/routes/ecgRoutes");

const app = express();
app.use(express.json());
const port = 3000;
/** 
 * 실행방법
 * npm run dev
 */

// 접속하는 방법
/**
 * localhost:3000 또는 127.0.0.1:3000
 */

app.use("/ecg", ecgRoutes);

// 기본 라우트
app.get("/", (req, res) => {
    res.send("Hello World!");
});
app.get("/", (req, res) => {
    res.send("서버 정상 작동 중");
});


// 서버 시작
app.listen(port, '0.0.0.0', () => {
    console.log(`서버가 http://localhost:${port} 에서 실행 중입니다.`);
});
