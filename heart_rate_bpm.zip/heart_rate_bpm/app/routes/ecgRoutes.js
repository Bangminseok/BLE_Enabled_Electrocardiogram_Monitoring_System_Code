// const express = require("express");
// const router = express.Router();
// const db = require("../../config/db");
// // const ecgController = require()

// // ecg 데이터 저장
// router.post("/store", async (req, res) => {
//     const {
//         row_data,
//         bpm_data,
//         sensor_measure_time
//     } = req.body;
//     console.log(req.body);

//     try {
//         const [result] = await db.query(
//             "INSERT INTO ecg (row_data, bpm_data, sensor_measure_time) VALUES (?, ?, ?)",
//             [row_data, bpm_data, sensor_measure_time]
//         );
//         res.json({ id: result.insertId });
//     } catch (error) {
//         console.error("데이터를 추가하는 도중에 오류가 발생하였습니다.:", error);
//         res.status(500).send("데이터 베이스 오류");
//     }
// });

// module.exports = router;

const express = require("express");
const router = express.Router();
const db = require("../../config/db");

router.post("/store", async (req, res) => {
    const { row_data } = req.body;

    if (!Array.isArray(row_data)) {
        return res.status(400).json({ error: "row_data는 배열이어야 합니다." });
    }

    try {
        const values = row_data.map(value => [value]);
        const sql = `
            INSERT INTO ecg_tb (row_data, sensor_measure_time)
            VALUES ${values.map(() => '(?, NOW())').join(', ')}
        `;
        const flatValues = values.flat();

        const [result] = await db.query(sql, flatValues);

        res.json({ inserted: values.length, insertIdStart: result.insertId });
    } catch (error) {
        console.error("데이터를 추가하는 도중에 오류가 발생하였습니다.:", error);
        res.status(500).send("데이터베이스 오류");
    }
});

module.exports = router;
