package com.example.nrf52840.ecg;

public class EcgLowPassFilter {
    private final double[] firCoefficients = {
            -0.001102, -0.000166,  0.003266,  0.002013,
            -0.005036, -0.004369,  0.009418,  0.011354,
            -0.015359, -0.023006,  0.020139,  0.046009,
            -0.021424, -0.099437,  0.017050,  0.331054,
            0.483745,
            0.331054,  0.017050, -0.099437, -0.021424,
            0.046009,  0.020139, -0.023006, -0.015359,
            0.011354,  0.009418, -0.004369, -0.005036,
            0.002013,  0.003266, -0.000166, -0.001102
    };


    private final double[] buffer = new double[firCoefficients.length];
    private int offset = 0;

    public float filter(float input) {
        buffer[offset] = input;
        double output = 0.0;
        int idx = offset;

        for (int i = 0; i < firCoefficients.length; i++) {
            output += firCoefficients[i] * buffer[idx];
            idx = (idx - 1 + firCoefficients.length) % firCoefficients.length;
        }

        offset = (offset + 1) % firCoefficients.length;
        return (float) output;
    }
}
